package io.cucumber;

import io.cucumber.java.en.*;
import io.cucumber.services.Actions;

public class StepsScenario3
{

    @Given("set Start Date: {string}")
    public void setStartDate(String string) {
        Comando.selectorQueryCss("#startdate").sendKeys(string);
    }

    @Given("set Insurance Sum [$] {double}.{int},{int}")
    public void setInsuranceSum(Double double1, Integer int1, Integer int2) {   
        Comando.selectorQueryXpath("//*[@id='insurancesum']/option[6]").click();
    }

    @Given("set Merit Rating: Bonus 1")
    public void setRatingSuperBonus() {
        Comando.selectorQueryXpath("//*[@id='meritrating']/option[3]").click();       
    }

    @Given("set Damage Insurance: No Coverage")
    public void setDamageInsurance() {
        Comando.selectorQueryXpath("//*[@id='damageinsurance']/option[2]").click();       

    } 

    @Given("set Optional Products: Euro Protection")
    public void setOptionalProducts() {
        Comando.selectorQueryXpath("//*[@id='insurance-form']/div/section[3]/div[5]/p/label[1]").click();       

    }

    @Given("set Courtesy Car: No")
    public void setCourtesyCar() {
        Actions.selectorQueryXpath("//*[@id='courtesycar']/option[2]").click();       

    } 

    @Then("click on Next")
    public void  clickOnNextPage3() {
        Actions.selectorQueryXpath("//*[@id='nextselectpriceoption']").click();       

    }

}