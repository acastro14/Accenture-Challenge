package io.cucumber;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.*;
import io.cucumber.services.Actions;

public class StepsScenario5 {
    @Given("set E-mail: {string}")
    public void setEmail(String string) {
        Actions.selectorQueryCss("#email").sendKeys(string);
    }
    
    @Given("set Phone: {string}")
    public void setPhone(String string) {
        Actions.selectorQueryCss("#phone").sendKeys(string);
    }
    
    @Given("set Username: {string}")
    public void setUsername(String string) {
        Actions.selectorQueryCss("#username").sendKeys(string);
    }
    
    @Given("set Password: {string}")
    public void setPassword(String string) {
        Actions.selectorQueryCss("#password").sendKeys(string);
    }
    
    @Given("confirm Password: {string}")
    public void confirmPassword(String string) {
        Action.selectorQueryCss("#confirmpassword").sendKeys(string);
    }
    
    @Then("click on Send")
    public void clickOnSend() {
        Action.selectorQueryCss("#sendemail").click();
    }
    
    @Then("verify the message: {string}")
    public void verifyMessage(String string) throws  InterruptedException{
        Thread.sleep(10000); 
        assertEquals(Actions.selectorQueryCss("body > div.sweet-alert.showSweetAlert.visible > h2").getText(), string);
        Action.close();
    }
}