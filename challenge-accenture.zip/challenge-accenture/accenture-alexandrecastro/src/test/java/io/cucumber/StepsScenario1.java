package io.cucumber;

import io.cucumber.java.en.*;
import io.cucumber.services.Actions;

public class StepsScenario1 {

    @When("access the Tricentis website: {string}")
    public void accessSiteTricentis(String string) {
        Actions.init(string);
    }

    @Given("click on Automobile")
    public void clickAutomobile() {
        Actions.selectorQueryCss("#nav_automobile").click();
    }

    @Given("click on option Make: Nissan")
    public void clickOnMakeNissan() {
        Actions.selectorQueryXpath("//*[@id='make']/option[8]").click();
    }  
    
    @Given("fill in field Engine Performance [kW]: {string}")
    public void enginePerformance(String string) {
        Actions.selectorQueryXpath("//*[@id='engineperformance']").sendKeys(string);
    }
    
    @Given("set Date of Manufacture: {string}")
    public void setDateManufacture(String string) {
        Actions.selectorQueryXpath("//*[@id='dateofmanufacture']").sendKeys(string);
    }
    
    @Given("click on Number of Seats 5")
    public void setNumberSeats() {
        Actions.selectorQueryXpath("//*[@id='numberofseats']/option[5]").click();
    }

    @Given("click on Fuel Type: Gas")
    public void setFuelGas() {
        Actions.selectorQueryXpath("//*[@id='fuel']/option[5]").click();
 
    }
    
    @Given("set List Price [$]: {string}")
    public void setListPrice(String string) {
        Actions.selectorQueryCss("#listprice").sendKeys(string);

    }
    
    @Given("set License Plate Number: {string}")
    public void setLicensePlateNumber(String string) {
        Actions.selectorQueryCss("#licenseplatenumber").sendKeys(string);

    }
    
    @Given("set Annual Mileage [mi]: {string}")
    public void setAnnualMileage(String string) {
        Actions.selectorQueryCss("#annualmileage").sendKeys(string);
    }
    
    @Then("click on Next")
    public void clickOnNextPage1() {
        Actions.selectorQueryXpath("//*[@id='nextenterinsurantdata']").click();
    }
}