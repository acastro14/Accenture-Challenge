package io.cucumber;

import io.cucumber.java.en.*;
import io.cucumber.services.Actions;

public class StepsScenario2 {

    @Given("set First Name {string}")
    public void setFirstName(String string) {
        Actions.selectorQueryCss("#firstname").sendKeys(string);
    }
    
    @Given("set Last Name {string}")
    public void setLastName(String string) {
        Actions.selectorQueryCss("#lastname").sendKeys(string);
    }
    
    @Given("set Date of Birth {string}")
    public void setDateBirth(String string) {
    	Actions.selectorQueryXpath("//*[@id='birthdate']").sendKeys(string);
    }
    
    @Given("set Gender: Male")
    public void genderMale() {
    	Actions.selectorQueryXpath("//*[@id='insurance-form']/div/section[2]/div[4]/p/label[1]/span").click();
    }
    
    @Given("set Street Address {string}")
    public void setStreetAddress(String string) {
    	Actions.selectorQueryCss("#streetaddress").sendKeys(string);
    }
    
    @Given("set Country: Albania")
    public void setCountry() {
    	Actions.selectorQueryXpath("//*[@id='country']/option[3]").click();

    }
    
    @Given("set Zip Code {string}")
    public void setZipCode(String string) {
    	Actions.selectorQueryCss("#zipcode").sendKeys(string);
    }
    
    @Given("set City {string}")
    public void setCity(String string) {
    	Actions.selectorQueryCss("#city").sendKeys(string);
    }
    
    @Given("set Occupation: Employee")
    public void setOccupationEmployee() {
    	Actions.selectorQueryXpath("//*[@id='occupation']/option[2]").click();
    }
    
    @Given("set Hoobies")
    public void setHoobies() {
    	Actions.selectorQueryXpath("//*[@id='insurance-form']/div/section[2]/div[10]/p/label[4]").click();
 
    }

    @Given("set Website: {string}")
    public void setWebsite(String string) {
    	Actions.selectorQueryCss("#website").sendKeys(string);

    }

    @Then("click on Next")
    public void  clickOnNextPage2() {
    	Actions.selectorQueryXpath("//*[@id='nextenterproductdata']").click();
    }
    
}