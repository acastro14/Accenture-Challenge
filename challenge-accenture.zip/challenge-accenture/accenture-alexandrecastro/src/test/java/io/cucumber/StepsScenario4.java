package io.cucumber;

import io.cucumber.java.en.*;
import io.cucumber.services.Actions;

public class StepsScenario4 {

    @Given("set price")
    public void setPrice() {
        Actions.selectorQueryXpath("//*[@id='priceTable']/tfoot/tr/th[2]/label[1]").click();
    }  
    
    @Then("click on Next")
    public void  clickOnNextPage4() throws InterruptedException{
        Thread.sleep(2000); 
        Actions.selectorQueryXpath("//*[@id='nextsendquote']").click();

    }
}